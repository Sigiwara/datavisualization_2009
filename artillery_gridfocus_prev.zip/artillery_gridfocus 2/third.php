<div id="tertCol">
	<?php include (TEMPLATEPATH . '/searchform.php'); ?>
	<div class="middle_links">
		<h3>Abonnieren</h3>
		<p>Sie können die Inhalte von <?php bloginfo('name'); ?> als RSS oder per Email abonnieren um immer auf dem neuesten Stand zu sein.</p>
		<ul>
			<li><a href="feed:<?php bloginfo('rss2_url'); ?>" title="Alle Artikel als RSS Feed">Artikel RSS</a></li>
			<li><a href="feed:<?php bloginfo('comments_rss2_url'); ?>" title="Alle Kommentare als RSS Feed">Kommentare RSS</a></li>
		</ul>
	</div>
	<?php 
		$before_cat = '<div class="middle_links">';
		$after_cat = '</div>';
		wp_list_bookmarks("category_before=$before_cat&category_after=$after_cat&title_before=<h3>&title_after=</h3>&title_li=Links");
	?>
</div><!-- close #tertCol -->