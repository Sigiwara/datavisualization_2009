<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//DE"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
	<!-- ——————————————————————————————————————————————————————————————————— Meta Tags -->
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
	<meta name="distribution" content="global" />
	<meta name="robots" content="follow, all" />
	<meta name="language" content="de" />
	<?php if ( is_single() ) { ?>
	<title><?php bloginfo('name'); ?> | <?php wp_title(''); ?></title>
	<!-- ——————————————————————————————————————————————————————————————————— Single -->
	<meta name="description" content="<?php bloginfo('name'); ?>, <?php bloginfo('description'); ?>" />
	<meta name="keywords" content="<?php wp_title(''); ?>, Benjamin Wiederkehr, Benjamin, Wiederkehr, Christian Siegrist, Christian, Siegrist, Visualisierung, Information, Data, Interaction Design, Interface Design" />
	<?php }; ?>
	<?php if ( ! is_single() ) { ?>
	<title><?php bloginfo('name'); ?> | <?php bloginfo('description'); ?></title>
	<!-- ——————————————————————————————————————————————————————————————————— Normal -->
	<meta name="description" content="<?php bloginfo('name'); ?>, <?php bloginfo('description'); ?>" />
	<meta name="keywords" content="<?php bloginfo('name'); ?>, Benjamin Wiederkehr, Benjamin, Wiederkehr, Christian Siegrist, Christian, Siegrist, Visualisierung, Information, Data, Interaction Design, Interface Design" />
	<?php }; ?>
	<!-- ——————————————————————————————————————————————————————————————————— Favicon -->
	<link rel="shortcut Icon" href="<?php echo get_bloginfo('template_directory'); ?>/images/favicon.ico" type="image/x-icon" />
	<link rel="icon" href="<?php echo get_bloginfo('template_directory'); ?>/images/favicon.ico" type="image/x-icon" />
	<!-- ——————————————————————————————————————————————————————————————————— RSS -->
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
	<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<!-- ——————————————————————————————————————————————————————————————————— CSS -->
	<link rel="stylesheet" type="text/css" media="screen" href="<?php bloginfo('stylesheet_url'); ?>" />
	<!-- ——————————————————————————————————————————————————————————————————— JS -->
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/base.js"></script>
	<!-- ——————————————————————————————————————————————————————————————————— WP HEAD -->
	<?php wp_head(); ?>
</head>
<body>
	<div id="wrapper">
	<div id="masthead" class="fix">
	<h1><a href="<?php echo get_settings('home'); ?>/"><?php bloginfo('name'); ?></a></h1>
		<div id="authorBlurb">
			<a href="http://portfolio.artillery.ch/?cat=22"><img src="<?php bloginfo('template_directory'); ?>/img/avatar_benji.png" alt="Avatar Benjamin" title="Avatar Benjamin" /></a>
			<a href="http://significant.ch"><img src="<?php bloginfo('template_directory'); ?>/img/avatar_chrigi.png" alt="Avatar Christian" title="Avatar Christian"/></a>
			<p id="authorIntro"><?php bloginfo('description'); ?></p>
		</div>
	</div>
	<ul class="nav fix">
		<li><a href="<?php echo get_settings('home'); ?>/" title="Return to the the frontpage">Home<br /><span>Frontpage</span></a></li>
		<li><a href="javascript:;" onmousedown="toggleDiv('archives');" title="View the archives">Archiv<br /><span>Alle Inhalte</span></a></li>
		<li><a href="<?php echo get_settings('home'); ?>/?page_id=2" title="Projectproposal">About<br /><span>über uns</span></a></li>
		<!-- <li><a href="<?php echo get_settings('home'); ?>/?page_id=16" title="Projectcalendar">Kontakt<br /><span></span></a></li> -->
	</ul>
	<div id="archives" class="fix" style="display: none;"> 
		<ul class="fix">
		<?php wp_list_cats('sort_column=name'); ?>
		</ul>
	</div>