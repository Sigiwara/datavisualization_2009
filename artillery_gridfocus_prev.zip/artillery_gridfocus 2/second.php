<div id="midCol">
	<div class="middle_links">
		<h3>Nach Kontext durchsuchen</h3>
		<!-- <p>Strukturierung basierend auf meinem Arbeitsfluss.</p> -->
		<ul>
			<?php wp_list_categories('sort_column=name&exclude=22&hide_empty=0&title_li=&show_count=1'); ?>
		</ul>
	</div>
	<div class="middle_links">
		<h3>Nach Datum durchsuchen</h3>
		<!-- <p>Zeitbasierte Strukturierung.</p> -->
		<ul>
			<?php wp_get_archives('type=monthly&format=html&show_post_count=1'); ?>
		</ul>
	</div>
	<div class="middle_links">
		<h3>Nach Autor durchsuchen</h3>
		<!-- <p>Autorbasierte Strukturierung.</p> -->
		<ul>
			<?php wp_list_authors('show_fullname=1&optioncount=1&hide_empty=0'); ?>
		</ul>
	</div>
	<div class="middle_links">
		<h3>Nach Taxonomie durchsuchen</h3>
		<!-- <p>Strukturierung basierend auf Schlagwörter.</p> -->
		<ul>
			<?php wp_tag_cloud('smallest=1&largest=1&unit=em&number=10&format=list&orderby=count&order=DESC&showcount=1'); ?>
		</ul>
	</div>
</div>